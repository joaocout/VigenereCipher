Joao Pedro Assuncao Coutinho - 180019813

Foram utilizados Python 3.10 e Ubuntu 22.04 para o desenvolvimento.

Para executar, basta rodar:

- Para a parte 1:
python3 vigenere.py

- Para a parte 2:
python3 attack.py